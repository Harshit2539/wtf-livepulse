import { useEffect, useState } from 'react';
import { useStore } from './store';
import { useWebSocket } from './hooks/useWebSocket';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';

const COLORS = ['#06B6D4', '#F59E0B', '#10B981', '#EF4444', '#8B5CF6'];

// ============================================================
// Styles (inline for single-file approach)
// ============================================================
const S = {
  app: { minHeight: '100vh', background: '#0D0D1A', color: '#E2E8F0', fontFamily: "'Inter', sans-serif" },
  nav: {
    background: '#0A0A14', borderBottom: '1px solid #1E1E3A',
    padding: '0 24px', display: 'flex', alignItems: 'center',
    gap: 24, height: 56, position: 'sticky', top: 0, zIndex: 100,
  },
  logo: { color: '#06B6D4', fontWeight: 700, fontSize: 18, letterSpacing: '-0.5px', whiteSpace: 'nowrap' },
  gymSelect: {
    background: '#1A1A2E', border: '1px solid #2D2D4E', color: '#E2E8F0',
    padding: '6px 12px', borderRadius: 6, fontSize: 13, cursor: 'pointer', minWidth: 200,
  },
  tabBar: { display: 'flex', gap: 4, marginLeft: 'auto' },
  tab: (active) => ({
    padding: '6px 16px', borderRadius: 6, fontSize: 13, cursor: 'pointer', fontWeight: 500,
    background: active ? '#06B6D4' : 'transparent',
    color: active ? '#0D0D1A' : '#94A3B8', border: 'none',
    transition: 'all 0.15s',
  }),
  content: { padding: '20px 24px', maxWidth: 1600, margin: '0 auto' },
  summaryBar: {
    display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20,
  },
  summaryCard: {
    background: '#1A1A2E', borderRadius: 10, padding: '14px 18px',
    border: '1px solid #2D2D4E',
  },
  summaryLabel: { fontSize: 11, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px' },
  summaryValue: { fontSize: 28, fontWeight: 700, marginTop: 4, fontFamily: "'JetBrains Mono', monospace" },
  grid2: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 },
  grid3: { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 },
  card: {
    background: '#1A1A2E', borderRadius: 10, padding: 20,
    border: '1px solid #2D2D4E',
  },
  cardTitle: { fontSize: 12, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 14 },
  bigNum: { fontSize: 42, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", lineHeight: 1 },
  badge: (severity) => ({
    display: 'inline-block', padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 600,
    background: severity === 'critical' ? '#EF444420' : '#F59E0B20',
    color: severity === 'critical' ? '#EF4444' : '#F59E0B',
    border: `1px solid ${severity === 'critical' ? '#EF444440' : '#F59E0B40'}`,
  }),
  dot: (connected) => ({
    width: 8, height: 8, borderRadius: '50%',
    background: connected ? '#10B981' : '#EF4444',
    display: 'inline-block', marginRight: 6,
    boxShadow: connected ? '0 0 6px #10B981' : 'none',
    animation: connected ? 'pulse 2s infinite' : 'none',
  }),
  feedItem: {
    padding: '8px 0', borderBottom: '1px solid #1E1E3A', fontSize: 12,
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
  },
  feedType: (type) => ({
    display: 'inline-block', width: 8, height: 8, borderRadius: '50%', marginRight: 8,
    background: type === 'CHECKIN_EVENT' ? '#10B981' : type === 'CHECKOUT_EVENT' ? '#F59E0B' : '#8B5CF6',
  }),
  occupancyBar: (pct) => ({
    height: 6, borderRadius: 3, marginTop: 8,
    background: `linear-gradient(90deg, ${pct > 85 ? '#EF4444' : pct > 60 ? '#F59E0B' : '#10B981'} ${pct}%, #2D2D4E ${pct}%)`,
  }),
  heatmapGrid: {
    display: 'grid', gridTemplateColumns: 'repeat(24, 1fr)', gap: 2,
  },
  heatCell: (intensity) => ({
    height: 18, borderRadius: 2,
    background: intensity === 0 ? '#1E1E3A' : `rgba(6,182,212,${Math.min(intensity, 1)})`,
  }),
  anomalyRow: {
    padding: '12px 0', borderBottom: '1px solid #1E1E3A',
    display: 'grid', gridTemplateColumns: '1fr 120px 80px 140px 100px',
    gap: 12, fontSize: 13, alignItems: 'center',
  },
  btn: (color) => ({
    padding: '8px 18px', borderRadius: 6, cursor: 'pointer', fontWeight: 600,
    fontSize: 13, border: 'none',
    background: color === 'primary' ? '#06B6D4' : color === 'danger' ? '#EF4444' : '#2D2D4E',
    color: color === 'primary' || color === 'danger' ? '#fff' : '#E2E8F0',
  }),
  skeleton: {
    background: 'linear-gradient(90deg, #1A1A2E 25%, #2D2D4E 50%, #1A1A2E 75%)',
    backgroundSize: '200% 100%', animation: 'shimmer 1.5s infinite',
    borderRadius: 6,
  },
};

// ============================================================
// Occupancy color helper
// ============================================================
function occupancyColor(pct) {
  if (pct > 85) return '#EF4444';
  if (pct > 60) return '#F59E0B';
  return '#10B981';
}

// ============================================================
// Format currency (INR)
// ============================================================
function fmtINR(n) {
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(1)}K`;
  return `₹${n}`;
}

function fmtTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

// ============================================================
// Skeleton loader
// ============================================================
function Skeleton({ width = '100%', height = 20, style = {} }) {
  return <div style={{ ...S.skeleton, width, height, ...style }} />;
}

// ============================================================
// Summary Bar
// ============================================================
function SummaryBar() {
  const { summary, gyms, anomalyCount, wsConnected } = useStore();
  return (
    <div style={S.summaryBar}>
      <div style={S.summaryCard}>
        <div style={S.summaryLabel}>Live Check-ins</div>
        <div style={{ ...S.summaryValue, color: '#06B6D4' }}>
          {summary.total_checked_in || 0}
        </div>
        <div style={{ fontSize: 11, color: '#64748B', marginTop: 4 }}>across all gyms</div>
      </div>
      <div style={S.summaryCard}>
        <div style={S.summaryLabel}>Today's Revenue</div>
        <div style={{ ...S.summaryValue, color: '#10B981' }}>
          {fmtINR(parseFloat(summary.total_today_revenue) || 0)}
        </div>
        <div style={{ fontSize: 11, color: '#64748B', marginTop: 4 }}>all locations</div>
      </div>
      <div style={S.summaryCard}>
        <div style={S.summaryLabel}>Active Anomalies</div>
        <div style={{ ...S.summaryValue, color: anomalyCount > 0 ? '#EF4444' : '#E2E8F0' }}>
          {anomalyCount}
        </div>
        <div style={{ fontSize: 11, color: '#64748B', marginTop: 4 }}>requiring attention</div>
      </div>
      <div style={S.summaryCard}>
        <div style={S.summaryLabel}>WebSocket Status</div>
        <div style={{ fontSize: 18, fontWeight: 600, marginTop: 8 }}>
          <span style={S.dot(wsConnected)} />
          {wsConnected ? 'Connected' : 'Reconnecting...'}
        </div>
        <div style={{ fontSize: 11, color: '#64748B', marginTop: 4 }}>
          {gyms.length} gyms active
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Live Dashboard Module
// ============================================================
function LiveDashboard() {
  const { liveData, activityFeed, gyms, selectedGymId } = useStore();
  const gym = gyms.find(g => g.id === selectedGymId);

  if (!liveData || !gym) {
    return (
      <div style={S.grid2}>
        <div style={S.card}><Skeleton height={120} /></div>
        <div style={S.card}><Skeleton height={120} /></div>
      </div>
    );
  }

  const { current_occupancy, today_revenue, occupancy_pct } = liveData;

  return (
    <>
      <div style={S.grid2}>
        {/* Occupancy */}
        <div style={S.card}>
          <div style={S.cardTitle}>Live Occupancy</div>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12 }}>
            <div style={{ ...S.bigNum, color: occupancyColor(occupancy_pct) }}>
              {current_occupancy}
            </div>
            <div style={{ fontSize: 20, color: '#64748B', paddingBottom: 6 }}>/ {gym.capacity}</div>
            <div style={{
              marginLeft: 'auto', fontSize: 32, fontWeight: 700,
              color: occupancyColor(occupancy_pct),
              fontFamily: "'JetBrains Mono', monospace",
            }}>
              {occupancy_pct}%
            </div>
          </div>
          <div style={S.occupancyBar(occupancy_pct)} />
          <div style={{ fontSize: 11, color: '#64748B', marginTop: 8 }}>
            {occupancy_pct < 60 ? '✓ Normal' : occupancy_pct < 85 ? '⚠ Getting busy' : '🔴 Near capacity'}
          </div>
        </div>

        {/* Revenue */}
        <div style={S.card}>
          <div style={S.cardTitle}>Today's Revenue</div>
          <div style={{ ...S.bigNum, color: '#10B981' }}>
            {fmtINR(today_revenue)}
          </div>
          <div style={{ fontSize: 12, color: '#64748B', marginTop: 8 }}>
            ₹{today_revenue?.toLocaleString('en-IN')} total collected today
          </div>
          <div style={{ fontSize: 11, color: '#64748B', marginTop: 4 }}>
            {gym.city} • {gym.name.replace('WTF Gyms - ', '')}
          </div>
        </div>
      </div>

      {/* Activity Feed */}
      <div style={S.card}>
        <div style={S.cardTitle}>Live Activity Feed</div>
        {activityFeed.length === 0 ? (
          <div style={{ color: '#64748B', fontSize: 13, textAlign: 'center', padding: 20 }}>
            Waiting for events... Start the simulator to see live activity.
          </div>
        ) : (
          activityFeed.map((ev, i) => (
            <div key={i} style={S.feedItem}>
              <div>
                <span style={S.feedType(ev.type)} />
                <span style={{ fontWeight: 500 }}>{ev.member_name}</span>
                {' '}
                <span style={{ color: '#64748B' }}>
                  {ev.type === 'CHECKIN_EVENT' ? 'checked in at' :
                   ev.type === 'CHECKOUT_EVENT' ? 'checked out from' : 'paid at'}
                  {' '}
                </span>
                <span style={{ color: '#94A3B8' }}>
                  {ev.gym_name?.replace('WTF Gyms - ', '')}
                </span>
                {ev.amount && (
                  <span style={{ color: '#10B981', marginLeft: 8 }}>+₹{ev.amount}</span>
                )}
              </div>
              <div style={{ color: '#64748B', fontSize: 11 }}>{fmtTime(ev.timestamp)}</div>
            </div>
          ))
        )}
      </div>
    </>
  );
}

// ============================================================
// Analytics Module
// ============================================================
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function HeatmapCell({ count, max }) {
  const intensity = max > 0 ? count / max : 0;
  return <div style={S.heatCell(intensity)} title={`${count} check-ins`} />;
}

function AnalyticsModule() {
  const { analytics, selectedGymId, fetchAnalytics } = useStore();
  const [range, setRange] = useState('30d');

  useEffect(() => {
    if (selectedGymId) fetchAnalytics(selectedGymId, range);
  }, [range]);

  if (!analytics) return <div style={S.card}><Skeleton height={200} /></div>;

  const { heatmap, revenue_by_plan, churn_risk, new_vs_renewal } = analytics;

  // Build heatmap grid: 7 days x 24 hours
  const heatGrid = Array(7).fill(null).map((_, d) =>
    Array(24).fill(0).map((_, h) => {
      const cell = heatmap.find(c => c.day_of_week === d && c.hour_of_day === h);
      return cell ? parseInt(cell.checkin_count, 10) : 0;
    })
  );
  const maxHeat = Math.max(...heatGrid.flat(), 1);

  const revenueData = revenue_by_plan.map(r => ({
    name: r.plan_type,
    amount: parseFloat(r.total),
  }));

  const ratioData = new_vs_renewal.map(r => ({
    name: r.member_type === 'new' ? 'New' : 'Renewal',
    value: parseInt(r.count, 10),
  }));

  return (
    <>
      {/* Date range selector */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {['7d', '30d', '90d'].map(r => (
          <button key={r} style={S.tab(range === r)} onClick={() => setRange(r)}>
            {r === '7d' ? 'Last 7 Days' : r === '30d' ? 'Last 30 Days' : 'Last 90 Days'}
          </button>
        ))}
      </div>

      {/* Heatmap */}
      <div style={{ ...S.card, marginBottom: 16 }}>
        <div style={S.cardTitle}>Peak Hours Heatmap (7-day rolling)</div>
        <div style={{ overflowX: 'auto' }}>
          {DAYS.map((day, d) => (
            <div key={d} style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 4 }}>
              <div style={{ width: 32, fontSize: 11, color: '#64748B', flexShrink: 0 }}>{day}</div>
              {heatGrid[d].map((count, h) => (
                <HeatmapCell key={h} count={count} max={maxHeat} />
              ))}
            </div>
          ))}
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
            <div style={{ width: 32 }} />
            {Array(24).fill(0).map((_, h) => (
              <div key={h} style={{ fontSize: 9, color: '#374151', textAlign: 'center', flex: 1 }}>
                {h % 3 === 0 ? h : ''}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={S.grid2}>
        {/* Revenue by plan */}
        <div style={S.card}>
          <div style={S.cardTitle}>Revenue by Plan Type</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={revenueData} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
              <XAxis dataKey="name" tick={{ fill: '#64748B', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => fmtINR(v)} />
              <Tooltip
                formatter={(v) => [`₹${v.toLocaleString('en-IN')}`, 'Revenue']}
                contentStyle={{ background: '#1A1A2E', border: '1px solid #2D2D4E', borderRadius: 6, fontSize: 12 }}
              />
              <Bar dataKey="amount" fill="#06B6D4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* New vs Renewal */}
        <div style={S.card}>
          <div style={S.cardTitle}>New vs Renewal Members</div>
          {ratioData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={ratioData} cx="50%" cy="50%" innerRadius={50} outerRadius={80}
                     paddingAngle={3} dataKey="value">
                  {ratioData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i]} />
                  ))}
                </Pie>
                <Legend formatter={(v) => <span style={{ color: '#94A3B8', fontSize: 12 }}>{v}</span>} />
                <Tooltip contentStyle={{ background: '#1A1A2E', border: '1px solid #2D2D4E', borderRadius: 6 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ color: '#64748B', textAlign: 'center', padding: 60 }}>No data</div>
          )}
        </div>
      </div>

      {/* Churn Risk Panel */}
      <div style={{ ...S.card, marginTop: 16 }}>
        <div style={S.cardTitle}>
          Churn Risk Members — {churn_risk?.length || 0} at risk
        </div>
        {churn_risk?.length === 0 ? (
          <div style={{ color: '#10B981', fontSize: 13, padding: '8px 0' }}>✓ No members at churn risk</div>
        ) : (
          <div style={{ maxHeight: 300, overflowY: 'auto' }}>
            {churn_risk?.slice(0, 50).map((m) => (
              <div key={m.id} style={{ ...S.feedItem, gridTemplateColumns: '1fr 180px 80px' }}>
                <div style={{ fontWeight: 500, fontSize: 13 }}>{m.name}</div>
                <div style={{ color: '#64748B', fontSize: 12 }}>
                  Last: {m.last_checkin_at ? new Date(m.last_checkin_at).toLocaleDateString('en-IN') : 'Never'}
                </div>
                <div style={S.badge(m.risk_level === 'CRITICAL' ? 'critical' : 'warning')}>
                  {m.risk_level}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

// ============================================================
// Anomaly Module
// ============================================================
function AnomalyModule() {
  const { anomalies, dismissAnomaly } = useStore();

  return (
    <div style={S.card}>
      <div style={S.cardTitle}>Anomaly Detection Log — {anomalies.length} active</div>

      {anomalies.length === 0 ? (
        <div style={{ color: '#10B981', fontSize: 13, padding: '20px 0', textAlign: 'center' }}>
          ✓ No active anomalies across all gyms
        </div>
      ) : (
        <>
          <div style={{ ...S.anomalyRow, color: '#64748B', fontSize: 11 }}>
            <div>GYM & MESSAGE</div>
            <div>TYPE</div>
            <div>SEVERITY</div>
            <div>DETECTED</div>
            <div>ACTION</div>
          </div>
          {anomalies.map((a) => (
            <div key={a.id} style={{
              ...S.anomalyRow,
              background: a.resolved ? 'transparent' : a.severity === 'critical' ? '#EF444408' : '#F59E0B08',
            }}>
              <div>
                <div style={{ fontWeight: 500, fontSize: 13 }}>{a.gym_name}</div>
                <div style={{ color: '#64748B', fontSize: 12, marginTop: 2 }}>{a.message}</div>
              </div>
              <div style={{ fontSize: 12, color: '#94A3B8' }}>
                {a.type?.replace('_', ' ')}
              </div>
              <div>
                <span style={S.badge(a.severity)}>{a.severity?.toUpperCase()}</span>
              </div>
              <div style={{ fontSize: 12, color: '#64748B' }}>
                {a.detected_at ? new Date(a.detected_at).toLocaleTimeString('en-IN') : ''}
              </div>
              <div>
                {a.resolved ? (
                  <span style={{ color: '#10B981', fontSize: 12 }}>✓ Resolved</span>
                ) : a.severity === 'warning' ? (
                  <button
                    style={{ ...S.btn('default'), padding: '4px 10px', fontSize: 11 }}
                    onClick={() => {
                      if (confirm('Dismiss this warning?')) dismissAnomaly(a.id);
                    }}
                  >
                    Dismiss
                  </button>
                ) : (
                  <span style={{ color: '#EF4444', fontSize: 12 }}>Auto-resolve only</span>
                )}
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

// ============================================================
// Simulator Controls
// ============================================================
function SimulatorControls() {
  const { simStatus, startSimulator, stopSimulator, resetSimulator } = useStore();

  return (
    <div style={{ ...S.card, marginBottom: 16, display: 'flex', gap: 16, alignItems: 'center' }}>
      <div>
        <div style={S.cardTitle}>Simulator Controls</div>
        <div style={{ fontSize: 13, color: simStatus.isRunning ? '#10B981' : '#64748B' }}>
          <span style={S.dot(simStatus.isRunning)} />
          {simStatus.isRunning ? `Running at ${simStatus.speed}x` : 'Paused'}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginLeft: 'auto', alignItems: 'center' }}>
        <span style={{ fontSize: 12, color: '#64748B' }}>Speed:</span>
        {[1, 5, 10].map(s => (
          <button
            key={s}
            style={S.tab(simStatus.speed === s && simStatus.isRunning)}
            onClick={() => startSimulator(s)}
          >
            {s}x
          </button>
        ))}
        <button style={S.btn(simStatus.isRunning ? 'danger' : 'primary')}
          onClick={() => simStatus.isRunning ? stopSimulator() : startSimulator(simStatus.speed || 1)}>
          {simStatus.isRunning ? '⏸ Pause' : '▶ Start'}
        </button>
        <button style={S.btn('default')} onClick={() => {
          if (confirm('Reset simulator to baseline?')) resetSimulator();
        }}>
          ↺ Reset
        </button>
      </div>
    </div>
  );
}

// ============================================================
// Cross-gym Revenue Chart
// ============================================================
function CrossGymChart() {
  const [data, setData] = useState([]);
  const API = import.meta.env.VITE_API_URL || 'http://localhost:3001';

  useEffect(() => {
    fetch(`${API}/api/analytics/cross-gym`)
      .then(r => r.json())
      .then(rows => setData(rows.map(r => ({
        name: r.gym_name.replace('WTF Gyms - ', ''),
        revenue: parseFloat(r.total_revenue),
      }))))
      .catch(console.error);
  }, []);

  return (
    <div style={{ ...S.card, marginTop: 16 }}>
      <div style={S.cardTitle}>Cross-Gym Revenue (Last 30 Days)</div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={data} layout="vertical" margin={{ left: 20 }}>
          <XAxis type="number" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false}
            tickFormatter={v => fmtINR(v)} />
          <YAxis type="category" dataKey="name" tick={{ fill: '#94A3B8', fontSize: 11 }}
            axisLine={false} width={110} />
          <Tooltip formatter={(v) => [`₹${v.toLocaleString('en-IN')}`, 'Revenue']}
            contentStyle={{ background: '#1A1A2E', border: '1px solid #2D2D4E', borderRadius: 6, fontSize: 12 }} />
          <Bar dataKey="revenue" fill="#06B6D4" radius={[0, 4, 4, 0]}
            label={{ position: 'right', formatter: v => fmtINR(v), fill: '#64748B', fontSize: 10 }} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// ============================================================
// Root App
// ============================================================
export default function App() {
  const {
    gyms, selectedGymId, activeTab, anomalyCount, wsConnected,
    fetchGyms, fetchAnomalies, fetchSummary, setSelectedGym, setActiveTab,
  } = useStore();

  useWebSocket();

  useEffect(() => {
    fetchGyms();
    fetchAnomalies();
    fetchSummary();

    // Refresh summary every 15s
    const t = setInterval(() => { fetchSummary(); fetchAnomalies(); }, 15000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={S.app}>
      {/* Global keyframe styles */}
      <style>{`
        @keyframes pulse { 0%,100%{opacity:1}50%{opacity:0.4} }
        @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#0D0D1A}
        ::-webkit-scrollbar-thumb{background:#2D2D4E;border-radius:3px}
        button:hover{opacity:0.85}
      `}</style>

      {/* Navigation */}
      <nav style={S.nav}>
        <div style={S.logo}>⚡ WTF LivePulse</div>

        <select
          style={S.gymSelect}
          value={selectedGymId || ''}
          onChange={e => setSelectedGym(e.target.value)}
        >
          {gyms.map(g => (
            <option key={g.id} value={g.id}>
              {g.name.replace('WTF Gyms - ', '')} • {g.city}
            </option>
          ))}
        </select>

        <div style={S.tabBar}>
          <button style={S.tab(activeTab === 'dashboard')} onClick={() => setActiveTab('dashboard')}>
            Dashboard
          </button>
          <button style={S.tab(activeTab === 'analytics')} onClick={() => setActiveTab('analytics')}>
            Analytics
          </button>
          <button style={{
            ...S.tab(activeTab === 'anomalies'),
            position: 'relative',
          }} onClick={() => setActiveTab('anomalies')}>
            Anomalies
            {anomalyCount > 0 && (
              <span style={{
                position: 'absolute', top: -4, right: -4,
                background: '#EF4444', color: '#fff', borderRadius: '50%',
                width: 16, height: 16, fontSize: 10, fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {anomalyCount > 9 ? '9+' : anomalyCount}
              </span>
            )}
          </button>
        </div>
      </nav>

      {/* Main content */}
      <main style={S.content}>
        <SummaryBar />
        <SimulatorControls />

        {activeTab === 'dashboard' && <LiveDashboard />}
        {activeTab === 'analytics' && (
          <>
            <AnalyticsModule />
            <CrossGymChart />
          </>
        )}
        {activeTab === 'anomalies' && <AnomalyModule />}
      </main>
    </div>
  );
}
