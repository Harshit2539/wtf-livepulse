import { create } from 'zustand';

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001';
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3001';

export const useStore = create((set, get) => ({
  // Gym data
  gyms: [],
  selectedGymId: null,
  liveData: null,
  analytics: null,

  // Anomalies
  anomalies: [],
  anomalyCount: 0,

  // Activity feed (last 20 events across all gyms)
  activityFeed: [],

  // Summary
  summary: { total_checked_in: 0, total_today_revenue: 0, active_anomalies: 0 },

  // WebSocket
  wsConnected: false,

  // Simulator
  simStatus: { isRunning: false, speed: 1 },

  // UI
  activeTab: 'dashboard', // dashboard | analytics | anomalies

  setActiveTab: (tab) => set({ activeTab: tab }),

  setSelectedGym: (id) => {
    set({ selectedGymId: id, liveData: null, analytics: null });
    get().fetchLiveData(id);
    get().fetchAnalytics(id);
  },

  fetchGyms: async () => {
    try {
      const res = await fetch(`${API}/api/gyms`);
      const gyms = await res.json();
      set({ gyms });
      if (!get().selectedGymId && gyms.length > 0) {
        get().setSelectedGym(gyms[0].id);
      }
    } catch (err) {
      console.error('Failed to fetch gyms:', err);
    }
  },

  fetchLiveData: async (gymId) => {
    if (!gymId) return;
    try {
      const res = await fetch(`${API}/api/gyms/${gymId}/live`);
      const data = await res.json();
      set({ liveData: data });
    } catch (err) {
      console.error('Failed to fetch live data:', err);
    }
  },

  fetchAnalytics: async (gymId, range = '30d') => {
    if (!gymId) return;
    try {
      const res = await fetch(`${API}/api/gyms/${gymId}/analytics?dateRange=${range}`);
      const data = await res.json();
      set({ analytics: data });
    } catch (err) {
      console.error('Failed to fetch analytics:', err);
    }
  },

  fetchAnomalies: async () => {
    try {
      const res = await fetch(`${API}/api/anomalies`);
      const data = await res.json();
      set({ anomalies: data, anomalyCount: data.length });
    } catch (err) {
      console.error('Failed to fetch anomalies:', err);
    }
  },

  fetchSummary: async () => {
    try {
      const res = await fetch(`${API}/api/analytics/summary`);
      const data = await res.json();
      set({ summary: data });
    } catch (err) {
      console.error('Failed to fetch summary:', err);
    }
  },

  handleWsEvent: (event) => {
    const state = get();

    if (event.type === 'CHECKIN_EVENT' || event.type === 'CHECKOUT_EVENT') {
      // Update gym occupancy in list
      set(s => ({
        gyms: s.gyms.map(g =>
          g.id === event.gym_id
            ? { ...g, current_occupancy: event.current_occupancy, occupancy_pct: event.capacity_pct }
            : g
        ),
        // Update live data if this is the selected gym
        liveData: s.liveData && s.liveData.gym?.id === event.gym_id
          ? { ...s.liveData, current_occupancy: event.current_occupancy, occupancy_pct: event.capacity_pct }
          : s.liveData,
        // Add to activity feed
        activityFeed: [
          {
            type: event.type,
            member_name: event.member_name,
            gym_id: event.gym_id,
            gym_name: s.gyms.find(g => g.id === event.gym_id)?.name || '',
            timestamp: event.timestamp,
          },
          ...s.activityFeed.slice(0, 19),
        ],
      }));

      // Update summary
      get().fetchSummary();
    }

    if (event.type === 'PAYMENT_EVENT') {
      set(s => ({
        gyms: s.gyms.map(g =>
          g.id === event.gym_id
            ? { ...g, today_revenue: event.today_total }
            : g
        ),
        liveData: s.liveData && s.liveData.gym?.id === event.gym_id
          ? { ...s.liveData, today_revenue: event.today_total }
          : s.liveData,
        activityFeed: [
          {
            type: 'PAYMENT_EVENT',
            member_name: event.member_name,
            gym_id: event.gym_id,
            gym_name: s.gyms.find(g => g.id === event.gym_id)?.name || '',
            amount: event.amount,
            plan_type: event.plan_type,
            timestamp: new Date().toISOString(),
          },
          ...s.activityFeed.slice(0, 19),
        ],
      }));
      get().fetchSummary();
    }

    if (event.type === 'ANOMALY_DETECTED') {
      set(s => ({
        anomalies: [
          {
            id: event.anomaly_id,
            gym_id: event.gym_id,
            gym_name: event.gym_name,
            type: event.anomaly_type,
            severity: event.severity,
            message: event.message,
            resolved: false,
            detected_at: new Date().toISOString(),
          },
          ...s.anomalies,
        ],
        anomalyCount: s.anomalyCount + 1,
      }));
    }

    if (event.type === 'ANOMALY_RESOLVED') {
      set(s => ({
        anomalies: s.anomalies.map(a =>
          a.id === event.anomaly_id
            ? { ...a, resolved: true, resolved_at: event.resolved_at }
            : a
        ),
        anomalyCount: Math.max(0, s.anomalyCount - 1),
      }));
    }
  },

  setWsConnected: (val) => set({ wsConnected: val }),

  startSimulator: async (speed) => {
    await fetch(`${API}/api/simulator/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ speed }),
    });
    set({ simStatus: { isRunning: true, speed } });
  },

  stopSimulator: async () => {
    await fetch(`${API}/api/simulator/stop`, { method: 'POST' });
    set(s => ({ simStatus: { ...s.simStatus, isRunning: false } }));
  },

  resetSimulator: async () => {
    await fetch(`${API}/api/simulator/reset`, { method: 'POST' });
    set(s => ({ simStatus: { ...s.simStatus, isRunning: false } }));
    get().fetchGyms();
  },

  dismissAnomaly: async (id) => {
    await fetch(`${API}/api/anomalies/${id}/dismiss`, { method: 'PATCH' });
    set(s => ({
      anomalies: s.anomalies.filter(a => a.id !== id),
      anomalyCount: Math.max(0, s.anomalyCount - 1),
    }));
  },
}));

export const WS_URL_EXPORT = WS_URL;
