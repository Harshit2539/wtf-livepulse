import { useEffect, useRef } from 'react';
import { useStore, WS_URL_EXPORT } from '../store';

export function useWebSocket() {
  const wsRef = useRef(null);
  const { handleWsEvent, setWsConnected } = useStore();

  useEffect(() => {
    let reconnectTimer = null;

    function connect() {
      const ws = new WebSocket(WS_URL_EXPORT);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        console.log('[WS] Connected');
      };

      ws.onmessage = (e) => {
        try {
          const event = JSON.parse(e.data);
          handleWsEvent(event);
        } catch (err) {
          console.error('[WS] Parse error:', err);
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        console.log('[WS] Disconnected. Reconnecting in 3s...');
        reconnectTimer = setTimeout(connect, 3000);
      };

      ws.onerror = (err) => {
        console.error('[WS] Error:', err);
        ws.close();
      };
    }

    connect();

    return () => {
      clearTimeout(reconnectTimer);
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  return wsRef;
}
