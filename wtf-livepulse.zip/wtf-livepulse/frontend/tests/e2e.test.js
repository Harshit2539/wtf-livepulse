// @ts-check
const { test, expect } = require('@playwright/test');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

test.describe('WTF LivePulse E2E Tests', () => {

  test('dashboard loads and displays gym list without errors', async ({ page }) => {
    const errors = [];
    page.on('pageerror', err => errors.push(err.message));

    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    // Title visible
    await expect(page.locator('text=WTF LivePulse')).toBeVisible();

    // Gym dropdown has options
    const gymSelect = page.locator('select');
    await expect(gymSelect).toBeVisible();
    const options = await gymSelect.locator('option').count();
    expect(options).toBeGreaterThanOrEqual(10);

    // No JS errors
    expect(errors).toHaveLength(0);
  });

  test('switching gym in dropdown updates occupancy within 500ms', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    // Get first gym value
    const select = page.locator('select');
    const options = await select.locator('option').all();
    expect(options.length).toBeGreaterThanOrEqual(2);

    // Switch to second gym
    const secondValue = await options[1].getAttribute('value');
    await select.selectOption(secondValue);

    // Wait for occupancy counter to update (< 500ms)
    await page.waitForTimeout(600);

    // Occupancy counter should be visible
    const occupancyEl = page.locator('text=/\\d+ members|\\d+\\/\\d+/').first();
    await expect(occupancyEl).toBeVisible({ timeout: 2000 });
  });

  test('simulator start button triggers activity feed update within 5 seconds', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    // Start simulator at 10x speed
    const speedBtn = page.locator('button', { hasText: '10x' });
    if (await speedBtn.isVisible()) await speedBtn.click();

    const startBtn = page.locator('button', { hasText: /Start/ });
    await expect(startBtn).toBeVisible();
    await startBtn.click();

    // Wait for activity feed to show an event
    await expect(
      page.locator('text=/checked in|checked out|paid at/')
    ).toBeVisible({ timeout: 10000 });

    // Stop simulator
    const stopBtn = page.locator('button', { hasText: /Pause/ });
    if (await stopBtn.isVisible()) await stopBtn.click();
  });

  test('anomaly tab shows anomaly table', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    // Click anomalies tab
    const anomalyTab = page.locator('button', { hasText: /Anomalies/ });
    await anomalyTab.click();
    await page.waitForTimeout(500);

    // Anomaly log section visible
    await expect(
      page.locator('text=/Anomaly Detection Log|No active anomalies/')
    ).toBeVisible();
  });

  test('analytics tab shows heatmap and charts', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');

    const analyticsTab = page.locator('button', { hasText: 'Analytics' });
    await analyticsTab.click();
    await page.waitForTimeout(1000);

    // Peak hours heatmap heading visible
    await expect(page.locator('text=/Peak Hours Heatmap/')).toBeVisible({ timeout: 3000 });
  });
});
