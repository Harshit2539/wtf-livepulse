const pool = require('../db/pool');
const ws = require('../websocket');

/**
 * Check for zero check-ins anomaly.
 * Triggers if active gym has no check-ins in last 2 hours during operating hours (6am-10pm).
 */
async function checkZeroCheckins(client) {
  const now = new Date();
  const hour = now.getHours();

  // Only check during operating hours
  if (hour < 6 || hour >= 22) return [];

  const { rows } = await client.query(`
    SELECT g.id AS gym_id, g.name AS gym_name
    FROM gyms g
    WHERE g.status = 'active'
      AND NOT EXISTS (
        SELECT 1 FROM checkins c
        WHERE c.gym_id = g.id
          AND c.checked_in >= NOW() - INTERVAL '2 hours'
      )
      AND NOT EXISTS (
        SELECT 1 FROM anomalies a
        WHERE a.gym_id = g.id
          AND a.type = 'zero_checkins'
          AND a.resolved = FALSE
          AND a.dismissed = FALSE
      )
  `);

  const inserted = [];
  for (const row of rows) {
    const { rows: [anomaly] } = await client.query(`
      INSERT INTO anomalies (gym_id, type, severity, message)
      VALUES ($1, 'zero_checkins', 'warning', $2)
      RETURNING *
    `, [
      row.gym_id,
      `${row.gym_name} has had zero check-ins for over 2 hours during operating hours.`,
    ]);
    inserted.push({ ...anomaly, gym_name: row.gym_name });
  }

  // Auto-resolve: if gym now has a recent check-in
  await client.query(`
    UPDATE anomalies
    SET resolved = TRUE, resolved_at = NOW()
    WHERE type = 'zero_checkins'
      AND resolved = FALSE
      AND gym_id IN (
        SELECT DISTINCT gym_id FROM checkins
        WHERE checked_in >= NOW() - INTERVAL '2 hours'
      )
  `);

  return inserted;
}

/**
 * Check for capacity breach (> 90% occupancy).
 */
async function checkCapacityBreach(client) {
  const { rows } = await client.query(`
    SELECT
      g.id AS gym_id,
      g.name AS gym_name,
      g.capacity,
      COUNT(c.id) AS current_occupancy,
      ROUND(COUNT(c.id)::NUMERIC / g.capacity * 100, 1) AS occupancy_pct
    FROM gyms g
    LEFT JOIN checkins c ON c.gym_id = g.id AND c.checked_out IS NULL
    WHERE g.status = 'active'
    GROUP BY g.id, g.name, g.capacity
    HAVING COUNT(c.id)::NUMERIC / g.capacity > 0.90
  `);

  const inserted = [];
  for (const row of rows) {
    // Check if active anomaly already exists for this gym
    const existing = await client.query(`
      SELECT id FROM anomalies
      WHERE gym_id = $1 AND type = 'capacity_breach' AND resolved = FALSE
    `, [row.gym_id]);

    if (existing.rows.length > 0) continue;

    const { rows: [anomaly] } = await client.query(`
      INSERT INTO anomalies (gym_id, type, severity, message)
      VALUES ($1, 'capacity_breach', 'critical', $2)
      RETURNING *
    `, [
      row.gym_id,
      `${row.gym_name} is at ${row.occupancy_pct}% capacity (${row.current_occupancy}/${row.capacity} members).`,
    ]);
    inserted.push({ ...anomaly, gym_name: row.gym_name });
  }

  // Auto-resolve: occupancy dropped below 85%
  const { rows: toResolve } = await client.query(`
    UPDATE anomalies a
    SET resolved = TRUE, resolved_at = NOW()
    FROM (
      SELECT g.id AS gym_id, COUNT(c.id)::NUMERIC / g.capacity AS pct
      FROM gyms g
      LEFT JOIN checkins c ON c.gym_id = g.id AND c.checked_out IS NULL
      GROUP BY g.id, g.capacity
    ) occ
    WHERE a.gym_id = occ.gym_id
      AND a.type = 'capacity_breach'
      AND a.resolved = FALSE
      AND occ.pct < 0.85
    RETURNING a.id, a.gym_id
  `);

  return { inserted, resolved: toResolve };
}

/**
 * Check for revenue drop vs same day last week (>= 30% drop).
 */
async function checkRevenueDrop(client) {
  const { rows } = await client.query(`
    WITH today_rev AS (
      SELECT gym_id, COALESCE(SUM(amount), 0) AS today_total
      FROM payments
      WHERE paid_at >= CURRENT_DATE
      GROUP BY gym_id
    ),
    lastweek_rev AS (
      SELECT gym_id, COALESCE(SUM(amount), 0) AS lw_total
      FROM payments
      WHERE paid_at >= CURRENT_DATE - INTERVAL '7 days'
        AND paid_at < CURRENT_DATE - INTERVAL '6 days'
      GROUP BY gym_id
    )
    SELECT
      g.id AS gym_id,
      g.name AS gym_name,
      COALESCE(t.today_total, 0) AS today_total,
      COALESCE(l.lw_total, 0) AS lw_total
    FROM gyms g
    LEFT JOIN today_rev t ON t.gym_id = g.id
    LEFT JOIN lastweek_rev l ON l.gym_id = g.id
    WHERE g.status = 'active'
      AND COALESCE(l.lw_total, 0) > 0
      AND COALESCE(t.today_total, 0) < COALESCE(l.lw_total, 0) * 0.70
  `);

  const inserted = [];
  for (const row of rows) {
    const existing = await client.query(`
      SELECT id FROM anomalies
      WHERE gym_id = $1 AND type = 'revenue_drop' AND resolved = FALSE
    `, [row.gym_id]);

    if (existing.rows.length > 0) continue;

    const dropPct = row.lw_total > 0
      ? Math.round((1 - row.today_total / row.lw_total) * 100)
      : 0;

    const { rows: [anomaly] } = await client.query(`
      INSERT INTO anomalies (gym_id, type, severity, message)
      VALUES ($1, 'revenue_drop', 'warning', $2)
      RETURNING *
    `, [
      row.gym_id,
      `${row.gym_name} revenue is down ${dropPct}% vs same day last week (₹${row.today_total} vs ₹${row.lw_total}).`,
    ]);
    inserted.push({ ...anomaly, gym_name: row.gym_name });
  }

  // Auto-resolve: revenue within 20% of last week
  await client.query(`
    UPDATE anomalies a
    SET resolved = TRUE, resolved_at = NOW()
    FROM (
      WITH today_rev AS (
        SELECT gym_id, COALESCE(SUM(amount), 0) AS today_total
        FROM payments WHERE paid_at >= CURRENT_DATE GROUP BY gym_id
      ),
      lastweek_rev AS (
        SELECT gym_id, COALESCE(SUM(amount), 0) AS lw_total
        FROM payments
        WHERE paid_at >= CURRENT_DATE - INTERVAL '7 days'
          AND paid_at < CURRENT_DATE - INTERVAL '6 days'
        GROUP BY gym_id
      )
      SELECT g.id AS gym_id
      FROM gyms g
      LEFT JOIN today_rev t ON t.gym_id = g.id
      LEFT JOIN lastweek_rev l ON l.gym_id = g.id
      WHERE COALESCE(t.today_total, 0) >= COALESCE(l.lw_total, 0) * 0.80
    ) recovered
    WHERE a.gym_id = recovered.gym_id
      AND a.type = 'revenue_drop'
      AND a.resolved = FALSE
  `);

  return inserted;
}

/**
 * Run all anomaly checks. Called every 30 seconds by the job scheduler.
 */
async function runAnomalyDetection() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const zeroResults = await checkZeroCheckins(client);
    const { inserted: breachInserted, resolved: breachResolved } = await checkCapacityBreach(client);
    const dropResults = await checkRevenueDrop(client);

    await client.query('COMMIT');

    // Broadcast new anomalies
    for (const a of [...zeroResults, ...breachInserted, ...dropResults]) {
      ws.broadcastAnomalyDetected({
        anomaly_id: a.id,
        gym_id: a.gym_id,
        gym_name: a.gym_name,
        anomaly_type: a.type,
        severity: a.severity,
        message: a.message,
      });
    }

    // Broadcast resolved anomalies
    if (breachResolved && breachResolved.length > 0) {
      for (const r of breachResolved) {
        ws.broadcastAnomalyResolved({
          anomaly_id: r.id,
          gym_id: r.gym_id,
          resolved_at: new Date().toISOString(),
        });
      }
    }

    const total = zeroResults.length + breachInserted.length + dropResults.length;
    if (total > 0) {
      console.log(`[Anomaly] Detected ${total} new anomalies`);
    }

  } catch (err) {
    await client.query('ROLLBACK');
    console.error('[Anomaly] Detection error:', err.message);
  } finally {
    client.release();
  }
}

module.exports = {
  runAnomalyDetection,
  checkZeroCheckins,
  checkCapacityBreach,
  checkRevenueDrop,
};
