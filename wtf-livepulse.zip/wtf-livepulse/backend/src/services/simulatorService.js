const pool = require('../db/pool');
const ws = require('../websocket');

// Hourly traffic multipliers (index = hour of day)
const HOUR_WEIGHTS = [
  0.00, 0.00, 0.00, 0.00, 0.00, 0.30,  // 0-5
  0.60, 1.00, 1.00, 1.00, 0.40, 0.40,  // 6-11
  0.30, 0.30, 0.20, 0.20, 0.20, 0.90,  // 12-17
  0.90, 0.90, 0.90, 0.35, 0.15, 0.00,  // 18-23
];

const DOW_WEIGHTS = [0.45, 1.00, 0.95, 0.90, 0.95, 0.85, 0.70]; // Sun=0

let simulatorInterval = null;
let currentSpeed = 1; // 1x, 5x, 10x
let isRunning = false;

function getCurrentMultiplier() {
  const hour = new Date().getHours();
  const dow = new Date().getDay();
  return HOUR_WEIGHTS[hour] * DOW_WEIGHTS[dow];
}

async function getGymCapacity(gymId) {
  const { rows } = await pool.query(
    'SELECT capacity FROM gyms WHERE id = $1', [gymId]
  );
  return rows[0]?.capacity || 100;
}

async function getCurrentOccupancy(gymId) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) AS cnt FROM checkins WHERE gym_id = $1 AND checked_out IS NULL`,
    [gymId]
  );
  return parseInt(rows[0].cnt, 10);
}

async function simulateCheckin() {
  const multiplier = getCurrentMultiplier();
  if (multiplier === 0 || Math.random() > multiplier * 0.3 * currentSpeed) return;

  try {
    // Pick a random active gym
    const { rows: gyms } = await pool.query(
      `SELECT id, name, capacity FROM gyms WHERE status = 'active' ORDER BY random() LIMIT 1`
    );
    if (!gyms.length) return;
    const gym = gyms[0];

    const occupancy = await getCurrentOccupancy(gym.id);
    if (occupancy >= gym.capacity) return; // At capacity

    // Pick a random active member from that gym not currently checked in
    const { rows: members } = await pool.query(`
      SELECT m.id, m.name FROM members m
      WHERE m.gym_id = $1
        AND m.status = 'active'
        AND NOT EXISTS (
          SELECT 1 FROM checkins c
          WHERE c.member_id = m.id AND c.checked_out IS NULL
        )
      ORDER BY random()
      LIMIT 1
    `, [gym.id]);

    if (!members.length) return;
    const member = members[0];

    // Insert check-in
    await pool.query(
      `INSERT INTO checkins (member_id, gym_id, checked_in) VALUES ($1, $2, NOW())`,
      [member.id, gym.id]
    );

    // Update member's last_checkin_at
    await pool.query(
      `UPDATE members SET last_checkin_at = NOW() WHERE id = $1`,
      [member.id]
    );

    const newOccupancy = occupancy + 1;
    const capacityPct = Math.round((newOccupancy / gym.capacity) * 100);

    ws.broadcastCheckin({
      gym_id: gym.id,
      member_name: member.name,
      timestamp: new Date().toISOString(),
      current_occupancy: newOccupancy,
      capacity_pct: capacityPct,
    });

  } catch (err) {
    console.error('[Simulator] Check-in error:', err.message);
  }
}

async function simulateCheckout() {
  if (Math.random() > 0.4 * currentSpeed) return;

  try {
    // Find old open check-ins (> 45 mins) and close them
    const { rows } = await pool.query(`
      SELECT c.id, c.gym_id, m.name AS member_name,
             g.name AS gym_name, g.capacity
      FROM checkins c
      JOIN members m ON m.id = c.member_id
      JOIN gyms g ON g.id = c.gym_id
      WHERE c.checked_out IS NULL
        AND c.checked_in <= NOW() - INTERVAL '45 minutes'
      ORDER BY random()
      LIMIT 3
    `);

    for (const row of rows) {
      await pool.query(
        `UPDATE checkins SET checked_out = NOW() WHERE id = $1`,
        [row.id]
      );

      const occupancy = await getCurrentOccupancy(row.gym_id);
      const capacityPct = Math.round((occupancy / row.capacity) * 100);

      ws.broadcastCheckout({
        gym_id: row.gym_id,
        member_name: row.member_name,
        timestamp: new Date().toISOString(),
        current_occupancy: occupancy,
        capacity_pct: capacityPct,
      });
    }
  } catch (err) {
    console.error('[Simulator] Checkout error:', err.message);
  }
}

async function simulatePayment() {
  // Random payment, low probability
  if (Math.random() > 0.05 * currentSpeed) return;

  try {
    const { rows: members } = await pool.query(`
      SELECT m.id, m.name, m.gym_id, m.plan_type, g.name AS gym_name
      FROM members m
      JOIN gyms g ON g.id = m.gym_id
      WHERE m.status = 'active'
      ORDER BY random()
      LIMIT 1
    `);

    if (!members.length) return;
    const member = members[0];

    const amounts = { monthly: 1499, quarterly: 3999, annual: 11999 };
    const amount = amounts[member.plan_type];

    await pool.query(
      `INSERT INTO payments (member_id, gym_id, amount, plan_type, payment_type, paid_at)
       VALUES ($1, $2, $3, $4, 'new', NOW())`,
      [member.id, member.gym_id, amount, member.plan_type]
    );

    const { rows: [todayRev] } = await pool.query(
      `SELECT COALESCE(SUM(amount), 0) AS total FROM payments
       WHERE gym_id = $1 AND paid_at >= CURRENT_DATE`,
      [member.gym_id]
    );

    ws.broadcastPayment({
      gym_id: member.gym_id,
      amount,
      plan_type: member.plan_type,
      member_name: member.name,
      today_total: parseFloat(todayRev.total),
    });

  } catch (err) {
    console.error('[Simulator] Payment error:', err.message);
  }
}

function startSimulator(speed = 1) {
  if (isRunning) stopSimulator();

  currentSpeed = Math.min(10, Math.max(1, speed));
  isRunning = true;

  // Interval: 2000ms at 1x, 400ms at 5x, 200ms at 10x
  const intervalMs = Math.round(2000 / currentSpeed);

  simulatorInterval = setInterval(async () => {
    await simulateCheckin();
    await simulateCheckout();
    await simulatePayment();
  }, intervalMs);

  console.log(`[Simulator] Started at ${currentSpeed}x speed (${intervalMs}ms interval)`);
  return { status: 'running', speed: currentSpeed };
}

function stopSimulator() {
  if (simulatorInterval) {
    clearInterval(simulatorInterval);
    simulatorInterval = null;
  }
  isRunning = false;
  console.log('[Simulator] Stopped');
  return { status: 'paused' };
}

async function resetSimulator() {
  stopSimulator();

  // Close all currently open check-ins
  await pool.query(
    `UPDATE checkins SET checked_out = NOW()
     WHERE checked_out IS NULL AND checked_in <= NOW() - INTERVAL '2 minutes'`
  );

  console.log('[Simulator] Reset to baseline');
  return { status: 'reset' };
}

function getStatus() {
  return { isRunning, speed: currentSpeed };
}

module.exports = {
  startSimulator,
  stopSimulator,
  resetSimulator,
  getStatus,
  simulateCheckin,
  simulateCheckout,
};
