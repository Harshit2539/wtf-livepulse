const WebSocket = require('ws');

let wss = null;

function initWebSocket(server) {
  wss = new WebSocket.Server({ server });

  wss.on('connection', (ws, req) => {
    console.log(`WS client connected. Total: ${wss.clients.size}`);
    ws.isAlive = true;

    ws.on('pong', () => { ws.isAlive = true; });

    ws.on('close', () => {
      console.log(`WS client disconnected. Total: ${wss.clients.size}`);
    });

    ws.on('error', (err) => {
      console.error('WS client error:', err.message);
    });
  });

  // Heartbeat to detect broken connections
  const heartbeat = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) return ws.terminate();
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => clearInterval(heartbeat));

  console.log('WebSocket server initialised');
  return wss;
}

function broadcast(event) {
  if (!wss) return;
  const msg = JSON.stringify(event);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  });
}

function broadcastCheckin({ gym_id, member_name, timestamp, current_occupancy, capacity_pct }) {
  broadcast({
    type: 'CHECKIN_EVENT',
    gym_id, member_name, timestamp, current_occupancy, capacity_pct,
  });
}

function broadcastCheckout({ gym_id, member_name, timestamp, current_occupancy, capacity_pct }) {
  broadcast({
    type: 'CHECKOUT_EVENT',
    gym_id, member_name, timestamp, current_occupancy, capacity_pct,
  });
}

function broadcastPayment({ gym_id, amount, plan_type, member_name, today_total }) {
  broadcast({
    type: 'PAYMENT_EVENT',
    gym_id, amount, plan_type, member_name, today_total,
  });
}

function broadcastAnomalyDetected({ anomaly_id, gym_id, gym_name, anomaly_type, severity, message }) {
  broadcast({
    type: 'ANOMALY_DETECTED',
    anomaly_id, gym_id, gym_name, anomaly_type, severity, message,
  });
}

function broadcastAnomalyResolved({ anomaly_id, gym_id, resolved_at }) {
  broadcast({
    type: 'ANOMALY_RESOLVED',
    anomaly_id, gym_id, resolved_at,
  });
}

function getClientCount() {
  return wss ? wss.clients.size : 0;
}

module.exports = {
  initWebSocket,
  broadcast,
  broadcastCheckin,
  broadcastCheckout,
  broadcastPayment,
  broadcastAnomalyDetected,
  broadcastAnomalyResolved,
  getClientCount,
};
