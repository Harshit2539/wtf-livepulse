-- WTF LivePulse - Seed Script 002
-- Uses generate_series() for bulk performance. Targets < 60s execution.
-- Idempotent: safe to run multiple times.

DO $$
DECLARE
  -- Gym UUIDs stored for FK references
  gym_lajpat     UUID;
  gym_cp         UUID;
  gym_bandra     UUID;
  gym_powai      UUID;
  gym_indiranagar UUID;
  gym_koramangala UUID;
  gym_banjara    UUID;
  gym_noida      UUID;
  gym_saltlake   UUID;
  gym_velachery  UUID;

  v_count INTEGER;
BEGIN
  -- Skip if already seeded
  SELECT COUNT(*) INTO v_count FROM gyms;
  IF v_count >= 10 THEN
    RAISE NOTICE 'Database already seeded. Skipping.';
    RETURN;
  END IF;

  RAISE NOTICE 'Seeding gyms...';

  -- ============================================================
  -- 1. GYMS
  -- ============================================================
  INSERT INTO gyms (name, city, capacity, opens_at, closes_at, status)
  VALUES
    ('WTF Gyms — Lajpat Nagar',    'New Delhi',  220, '05:30', '22:30', 'active'),
    ('WTF Gyms — Connaught Place',  'New Delhi',  180, '06:00', '22:00', 'active'),
    ('WTF Gyms — Bandra West',      'Mumbai',     300, '05:00', '23:00', 'active'),
    ('WTF Gyms — Powai',            'Mumbai',     250, '05:30', '22:30', 'active'),
    ('WTF Gyms — Indiranagar',      'Bengaluru',  200, '05:30', '22:00', 'active'),
    ('WTF Gyms — Koramangala',      'Bengaluru',  180, '06:00', '22:00', 'active'),
    ('WTF Gyms — Banjara Hills',    'Hyderabad',  160, '06:00', '22:00', 'active'),
    ('WTF Gyms — Sector 18 Noida',  'Noida',      140, '06:00', '21:30', 'active'),
    ('WTF Gyms — Salt Lake',        'Kolkata',    120, '06:00', '21:00', 'active'),
    ('WTF Gyms — Velachery',        'Chennai',    110, '06:00', '21:00', 'active')
  ON CONFLICT DO NOTHING;

  SELECT id INTO gym_lajpat      FROM gyms WHERE name = 'WTF Gyms — Lajpat Nagar';
  SELECT id INTO gym_cp          FROM gyms WHERE name = 'WTF Gyms — Connaught Place';
  SELECT id INTO gym_bandra      FROM gyms WHERE name = 'WTF Gyms — Bandra West';
  SELECT id INTO gym_powai       FROM gyms WHERE name = 'WTF Gyms — Powai';
  SELECT id INTO gym_indiranagar FROM gyms WHERE name = 'WTF Gyms — Indiranagar';
  SELECT id INTO gym_koramangala FROM gyms WHERE name = 'WTF Gyms — Koramangala';
  SELECT id INTO gym_banjara     FROM gyms WHERE name = 'WTF Gyms — Banjara Hills';
  SELECT id INTO gym_noida       FROM gyms WHERE name = 'WTF Gyms — Sector 18 Noida';
  SELECT id INTO gym_saltlake    FROM gyms WHERE name = 'WTF Gyms — Salt Lake';
  SELECT id INTO gym_velachery   FROM gyms WHERE name = 'WTF Gyms — Velachery';

  RAISE NOTICE 'Seeding gyms... done';

  -- ============================================================
  -- 2. MEMBERS (5,000 total)
  -- Using a CTE with generate_series for bulk insert
  -- ============================================================
  RAISE NOTICE 'Seeding 5000 members...';

  INSERT INTO members (gym_id, name, email, phone, plan_type, member_type, status, joined_at, plan_expires_at, last_checkin_at)
  WITH

  -- Name pool (realistic Indian names)
  first_names(n) AS (
    SELECT unnest(ARRAY[
      'Rahul','Priya','Ankit','Neha','Arjun','Pooja','Vikram','Sneha','Rohit','Kavya',
      'Amit','Shreya','Kiran','Divya','Sanjay','Anjali','Ravi','Nisha','Suresh','Meera',
      'Arun','Tanya','Deepak','Rekha','Nikhil','Sonal','Manish','Preeti','Gaurav','Swati',
      'Harish','Bhavna','Ashish','Rupal','Tarun','Aarti','Vivek','Sunita','Naveen','Jyoti',
      'Manoj','Chitra','Pankaj','Lata','Vinay','Sarita','Akash','Radha','Kunal','Geeta',
      'Yash','Pallavi','Sachin','Usha','Sameer','Nilam','Rajesh','Vandana','Mukesh','Hema',
      'Dinesh','Sangita','Lalit','Pushpa','Sunil','Kamla','Aditya','Varsha','Girish','Smita',
      'Hardik','Sejal','Jay','Bindi','Dev','Nidhi','Sagar','Ritu','Pranav','Komal',
      'Chirag','Mansi','Parth','Foram','Neel','Khushboo','Varun','Isha','Tushar','Payal',
      'Abhinav','Surbhi','Mohit','Tanvi','Rishabh','Aishwarya','Shubham','Simran','Ayush','Ritika'
    ])
  ),
  last_names(n) AS (
    SELECT unnest(ARRAY[
      'Sharma','Mehta','Verma','Gupta','Patel','Singh','Yadav','Joshi','Agarwal','Rao',
      'Nair','Iyer','Pillai','Reddy','Naidu','Kumar','Mishra','Tiwari','Pandey','Dubey',
      'Shah','Desai','Jain','Malhotra','Kapoor','Khanna','Chopra','Bose','Ghosh','Sen',
      'Das','Datta','Roy','Mukherjee','Banerjee','Chatterjee','Sinha','Trivedi','Vyas','Patil',
      'Shinde','Jadhav','More','Pawar','Kulkarni','Gaikwad','Sawant','Kadam','Bhosale','Mane',
      'Nanda','Bhat','Kamath','Shetty','Poojari','Gowda','Hegde','Naik','Rane','Salvi'
    ])
  ),
  name_grid AS (
    SELECT
      f.n AS first_name,
      l.n AS last_name,
      ROW_NUMBER() OVER () AS rn
    FROM first_names f CROSS JOIN last_names l
  ),

  -- Gym distribution config
  gym_config(gym_id, member_count, monthly_pct, quarterly_pct, annual_pct, active_pct, start_seq) AS (
    VALUES
      (gym_lajpat,      650,  50, 30, 20, 88, 1),
      (gym_cp,          550,  40, 40, 20, 85, 651),
      (gym_bandra,      750,  40, 40, 20, 90, 1201),
      (gym_powai,       600,  40, 40, 20, 87, 1951),
      (gym_indiranagar, 550,  40, 40, 20, 89, 2551),
      (gym_koramangala, 500,  40, 40, 20, 86, 3101),
      (gym_banjara,     450,  50, 30, 20, 84, 3601),
      (gym_noida,       400,  60, 25, 15, 82, 4051),
      (gym_saltlake,    300,  60, 30, 10, 80, 4451),
      (gym_velachery,   250,  60, 30, 10, 78, 4751)
  ),

  member_rows AS (
    SELECT
      gc.gym_id,
      i,
      gc.start_seq + i - 1 AS global_seq,
      gc.member_count,
      gc.monthly_pct,
      gc.quarterly_pct,
      gc.active_pct,
      -- Plan type distribution
      CASE
        WHEN (i * 100.0 / gc.member_count) <= gc.monthly_pct THEN 'monthly'
        WHEN (i * 100.0 / gc.member_count) <= (gc.monthly_pct + gc.quarterly_pct) THEN 'quarterly'
        ELSE 'annual'
      END AS plan_type,
      -- Status: active%, inactive 8%, frozen 4% of remaining
      CASE
        WHEN (i * 100.0 / gc.member_count) <= gc.active_pct THEN 'active'
        WHEN (i * 100.0 / gc.member_count) <= (gc.active_pct + 8) THEN 'inactive'
        ELSE 'frozen'
      END AS status,
      -- member_type: 80% new, 20% renewal
      CASE WHEN i % 5 = 0 THEN 'renewal' ELSE 'new' END AS member_type
    FROM gym_config gc
    CROSS JOIN generate_series(1, gc.member_count) AS i
  ),

  member_with_dates AS (
    SELECT
      mr.*,
      ng.first_name || ' ' || ng.last_name AS full_name,
      -- joined_at: active members last 90 days, inactive 91-180 days ago
      CASE
        WHEN mr.status = 'active' THEN
          NOW() - (random() * INTERVAL '89 days') - INTERVAL '1 day'
        ELSE
          NOW() - INTERVAL '91 days' - (random() * INTERVAL '89 days')
      END AS joined_at
    FROM member_rows mr
    JOIN name_grid ng ON ng.rn = ((mr.global_seq - 1) % 6000) + 1
  )

  SELECT
    gym_id,
    full_name AS name,
    LOWER(
      REPLACE(SPLIT_PART(full_name, ' ', 1), ' ', '') || '.' ||
      REPLACE(SPLIT_PART(full_name, ' ', 2), ' ', '') ||
      global_seq::TEXT || '@gmail.com'
    ) AS email,
    -- Indian mobile: starts with 9, 8, or 7
    (ARRAY['9','8','7'])[1 + (global_seq % 3)] ||
      LPAD((global_seq * 97 % 1000000000)::TEXT, 9, '0') AS phone,
    plan_type,
    member_type,
    status,
    joined_at,
    CASE plan_type
      WHEN 'monthly'   THEN joined_at + INTERVAL '30 days'
      WHEN 'quarterly' THEN joined_at + INTERVAL '90 days'
      ELSE                  joined_at + INTERVAL '365 days'
    END AS plan_expires_at,
    NULL::TIMESTAMPTZ AS last_checkin_at  -- updated after check-ins seeded
  FROM member_with_dates
  ON CONFLICT (email) DO NOTHING;

  RAISE NOTICE 'Seeding 5000 members... done';

  -- ============================================================
  -- 3. CHECK-INS (90 days, ~270k records, batch via generate_series)
  -- ============================================================
  RAISE NOTICE 'Seeding 90 days of check-ins (~270k records)...';

  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  WITH
  daily_slots AS (
    SELECT
      m.id AS member_id,
      m.gym_id,
      m.joined_at,
      day_offset,
      (NOW() - (day_offset * INTERVAL '1 day'))::DATE AS slot_date
    FROM members m
    CROSS JOIN generate_series(1, 90) AS day_offset
    WHERE
      NOW() - (day_offset * INTERVAL '1 day') >= m.joined_at
      AND CASE
        WHEN m.status = 'active' THEN random() < 0.43
        WHEN m.status != 'active' THEN random() < 0.20
        ELSE FALSE
      END
  ),
  timed_checkins AS (
    SELECT
      member_id,
      gym_id,
      slot_date + make_interval(hours =>
        CASE (FLOOR(random() * 10))::INTEGER
          WHEN 0 THEN 6  WHEN 1 THEN 7  WHEN 2 THEN 8
          WHEN 3 THEN 9  WHEN 4 THEN 17 WHEN 5 THEN 18
          WHEN 6 THEN 19 WHEN 7 THEN 20 WHEN 8 THEN 10
          ELSE 11
        END
      ) + make_interval(mins => (random() * 55)::INTEGER) AS checked_in_ts
    FROM daily_slots
    WHERE random() < CASE EXTRACT(DOW FROM slot_date)::INTEGER
      WHEN 0 THEN 0.45 WHEN 1 THEN 1.0 WHEN 2 THEN 0.95
      WHEN 3 THEN 0.90 WHEN 4 THEN 0.95 WHEN 5 THEN 0.85
      ELSE 0.70
    END
  )
  SELECT
    member_id,
    gym_id,
    checked_in_ts AS checked_in,
    checked_in_ts + make_interval(mins => 45 + (random() * 45)::INTEGER) AS checked_out
  FROM timed_checkins
  WHERE checked_in_ts < NOW() - INTERVAL '2 hours';

  RAISE NOTICE 'Seeding 90 days of check-ins... done';

  -- ============================================================
  -- 4. UPDATE members.last_checkin_at from actual check-in data
  -- ============================================================
  RAISE NOTICE 'Syncing last_checkin_at...';

  UPDATE members m
  SET last_checkin_at = sub.latest
  FROM (
    SELECT member_id, MAX(checked_in) AS latest
    FROM checkins
    GROUP BY member_id
  ) sub
  WHERE m.id = sub.member_id;

  -- ============================================================
  -- 5. CHURN RISK POPULATION - override last_checkin_at for mandatory segments
  -- High Risk (45-60 days): 150+ active members
  -- Critical Risk (60+ days): 80+ active members
  -- ============================================================
  RAISE NOTICE 'Setting up churn risk population...';

  UPDATE members
  SET last_checkin_at = NOW() - INTERVAL '50 days' - (random() * INTERVAL '10 days')
  WHERE id IN (
    SELECT id FROM members
    WHERE status = 'active'
    ORDER BY random()
    LIMIT 180
  );

  UPDATE members
  SET last_checkin_at = NOW() - INTERVAL '65 days' - (random() * INTERVAL '20 days')
  WHERE id IN (
    SELECT id FROM members
    WHERE status = 'active'
      AND (last_checkin_at IS NULL OR last_checkin_at > NOW() - INTERVAL '45 days')
    ORDER BY random()
    LIMIT 100
  );

  -- Ensure actual checkin rows exist for churn members (data consistency)
  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT
    m.id,
    m.gym_id,
    m.last_checkin_at,
    m.last_checkin_at + make_interval(mins => 45 + (random() * 45)::INTEGER)
  FROM members m
  WHERE m.last_checkin_at < NOW() - INTERVAL '44 days'
    AND m.status = 'active'
  ON CONFLICT DO NOTHING;

  RAISE NOTICE 'Churn risk population... done';

  -- ============================================================
  -- 6. ANOMALY SCENARIO A: Velachery - Zero check-ins
  -- All open check-ins for Velachery must be closed
  -- Last checkin > 2 hours old
  -- ============================================================
  RAISE NOTICE 'Setting up anomaly scenario A (Velachery zero check-ins)...';

  -- Close any open sessions at Velachery
  UPDATE checkins
  SET checked_out = checked_in + INTERVAL '60 minutes'
  WHERE gym_id = gym_velachery AND checked_out IS NULL;

  -- Ensure most recent checkin is 2h15m+ ago
  UPDATE checkins
  SET checked_in = NOW() - INTERVAL '2 hours 20 minutes',
      checked_out = NOW() - INTERVAL '1 hour 20 minutes'
  WHERE id = (
    SELECT id FROM checkins WHERE gym_id = gym_velachery
    ORDER BY checked_in DESC LIMIT 1
  );

  RAISE NOTICE 'Anomaly scenario A done';

  -- ============================================================
  -- 7. ANOMALY SCENARIO B: Bandra West - Capacity Breach (275+ open check-ins)
  -- ============================================================
  RAISE NOTICE 'Setting up anomaly scenario B (Bandra West capacity breach)...';

  -- Close existing open sessions first
  UPDATE checkins
  SET checked_out = checked_in + INTERVAL '60 minutes'
  WHERE gym_id = gym_bandra AND checked_out IS NULL;

  -- Insert 280 open check-ins from Bandra members
  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT
    m.id,
    gym_bandra,
    NOW() - make_interval(mins => (random() * 80)::INTEGER + 5),
    NULL  -- open sessions = currently in gym
  FROM members m
  WHERE m.gym_id = gym_bandra AND m.status = 'active'
  ORDER BY random()
  LIMIT 280;

  RAISE NOTICE 'Anomaly scenario B done';

  -- ============================================================
  -- 8. ANOMALY SCENARIO C: Salt Lake - Revenue Drop
  -- Last week same day: 9 payments totalling ~18,000
  -- Today: 1 payment totalling ~1,499
  -- ============================================================
  RAISE NOTICE 'Setting up anomaly scenario C (Salt Lake revenue drop)...';

  -- Last week's payments (same weekday, 7 days ago)
  INSERT INTO payments (member_id, gym_id, amount, plan_type, payment_type, paid_at)
  SELECT
    m.id,
    gym_saltlake,
    CASE (ROW_NUMBER() OVER () % 3)
      WHEN 0 THEN 1499
      WHEN 1 THEN 3999
      ELSE 11999
    END AS amount,
    CASE (ROW_NUMBER() OVER () % 3)
      WHEN 0 THEN 'monthly'
      WHEN 1 THEN 'quarterly'
      ELSE 'annual'
    END AS plan_type,
    'new' AS payment_type,
    NOW() - INTERVAL '7 days' + make_interval(mins => (random() * 480)::INTEGER)
  FROM members m
  WHERE m.gym_id = gym_saltlake AND m.status = 'active'
  ORDER BY random()
  LIMIT 9;

  -- Today's payments (just 1 - creates the drop)
  INSERT INTO payments (member_id, gym_id, amount, plan_type, payment_type, paid_at)
  SELECT
    m.id,
    gym_saltlake,
    1499,
    'monthly',
    'new',
    NOW() - make_interval(mins => (random() * 120)::INTEGER)
  FROM members m
  WHERE m.gym_id = gym_saltlake AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM payments
      WHERE gym_id = gym_saltlake
        AND paid_at >= CURRENT_DATE
    )
  ORDER BY random()
  LIMIT 1;

  RAISE NOTICE 'Anomaly scenario C done';

  -- ============================================================
  -- 9. PAYMENTS for all members (at least 1 per member)
  -- ============================================================
  RAISE NOTICE 'Seeding payment history...';

  INSERT INTO payments (member_id, gym_id, amount, plan_type, payment_type, paid_at)
  SELECT
    m.id,
    m.gym_id,
    CASE m.plan_type
      WHEN 'monthly'   THEN 1499
      WHEN 'quarterly' THEN 3999
      ELSE 11999
    END AS amount,
    m.plan_type,
    'new' AS payment_type,
    m.joined_at + make_interval(secs => (random() * 300 - 150)::INTEGER)
  FROM members m
  WHERE m.id NOT IN (SELECT DISTINCT member_id FROM payments)
  ON CONFLICT DO NOTHING;

  -- Renewal payments for renewal members
  INSERT INTO payments (member_id, gym_id, amount, plan_type, payment_type, paid_at)
  SELECT
    m.id,
    m.gym_id,
    CASE m.plan_type
      WHEN 'monthly'   THEN 1499
      WHEN 'quarterly' THEN 3999
      ELSE 11999
    END AS amount,
    m.plan_type,
    'renewal' AS payment_type,
    CASE m.plan_type
      WHEN 'monthly'   THEN m.joined_at + INTERVAL '30 days'
      WHEN 'quarterly' THEN m.joined_at + INTERVAL '90 days'
      ELSE                  m.joined_at + INTERVAL '365 days'
    END
  FROM members m
  WHERE m.member_type = 'renewal'
    AND CASE m.plan_type
      WHEN 'monthly'   THEN m.joined_at + INTERVAL '30 days' < NOW()
      WHEN 'quarterly' THEN m.joined_at + INTERVAL '90 days' < NOW()
      ELSE                  m.joined_at + INTERVAL '365 days' < NOW()
    END
  ON CONFLICT DO NOTHING;

  RAISE NOTICE 'Payment history... done';

  -- ============================================================
  -- 10. PRE-SEEDED OPEN CHECK-INS (currently in gym, non-anomaly gyms)
  -- ============================================================
  RAISE NOTICE 'Seeding live occupancy data...';

  -- Large gyms: 25-35 open check-ins
  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id IN (gym_powai)
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_powai AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 28;

  -- Medium gyms: 15-25 open check-ins
  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id IN (gym_lajpat)
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_lajpat AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 20;

  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id IN (gym_cp)
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_cp AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 18;

  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id = gym_indiranagar
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_indiranagar AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 22;

  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id = gym_koramangala
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_koramangala AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 16;

  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id = gym_banjara
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_banjara AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 18;

  -- Small gyms: 8-15 open check-ins
  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id = gym_noida
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_noida AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 12;

  INSERT INTO checkins (member_id, gym_id, checked_in, checked_out)
  SELECT m.id, m.gym_id,
    NOW() - make_interval(mins => (random() * 75)::INTEGER + 10),
    NULL
  FROM members m
  WHERE m.gym_id = gym_saltlake
    AND m.status = 'active'
    AND m.id NOT IN (
      SELECT member_id FROM checkins WHERE gym_id = gym_saltlake AND checked_out IS NULL
    )
  ORDER BY random()
  LIMIT 10;

  -- Refresh the materialized view
  REFRESH MATERIALIZED VIEW gym_hourly_stats;

  RAISE NOTICE '===========================================';
  RAISE NOTICE 'Seed complete! Summary:';
  RAISE NOTICE '  Gyms: %',    (SELECT COUNT(*) FROM gyms);
  RAISE NOTICE '  Members: %', (SELECT COUNT(*) FROM members);
  RAISE NOTICE '  Active: %',  (SELECT COUNT(*) FROM members WHERE status = 'active');
  RAISE NOTICE '  Check-ins: %', (SELECT COUNT(*) FROM checkins);
  RAISE NOTICE '  Open sessions: %', (SELECT COUNT(*) FROM checkins WHERE checked_out IS NULL);
  RAISE NOTICE '  Payments: %', (SELECT COUNT(*) FROM payments);
  RAISE NOTICE '  Churn risk (45d+): %', (SELECT COUNT(*) FROM members WHERE status = 'active' AND last_checkin_at < NOW() - INTERVAL '45 days');
  RAISE NOTICE '===========================================';

END $$;
