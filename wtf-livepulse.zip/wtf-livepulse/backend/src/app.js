require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const { initWebSocket } = require('./websocket');
const { runAnomalyDetection } = require('./services/anomalyService');
const routes = require('./routes');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: '*' }));
app.use(express.json());

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

// API routes
app.use('/api', routes);

// 404 handler
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// Error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

const server = http.createServer(app);

// Initialise WebSocket server
initWebSocket(server);

// Start anomaly detection job (every 30 seconds)
let anomalyInterval = null;

function startAnomalyJob() {
  // Initial run after 5 seconds (allow seed to complete)
  setTimeout(() => {
    runAnomalyDetection().catch(console.error);
    anomalyInterval = setInterval(() => {
      runAnomalyDetection().catch(console.error);
    }, 30000);
  }, 5000);
}

server.listen(PORT, () => {
  console.log(`WTF LivePulse backend running on port ${PORT}`);
  startAnomalyJob();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down...');
  if (anomalyInterval) clearInterval(anomalyInterval);
  server.close(() => process.exit(0));
});

module.exports = { app, server };
