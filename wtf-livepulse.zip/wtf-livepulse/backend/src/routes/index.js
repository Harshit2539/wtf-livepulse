const express = require('express');
const router = express.Router();
const pool = require('../db/pool');
const { startSimulator, stopSimulator, resetSimulator, getStatus } = require('../services/simulatorService');

// ============================================================
// GET /api/gyms — all gyms with live occupancy and today's revenue
// ============================================================
router.get('/gyms', async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        g.id, g.name, g.city, g.capacity, g.status, g.opens_at, g.closes_at,
        COUNT(c.id) AS current_occupancy,
        ROUND(COUNT(c.id)::NUMERIC / g.capacity * 100, 1) AS occupancy_pct,
        COALESCE(p.today_revenue, 0) AS today_revenue,
        (SELECT COUNT(*) FROM anomalies a WHERE a.gym_id = g.id AND a.resolved = FALSE) AS active_anomalies
      FROM gyms g
      LEFT JOIN checkins c ON c.gym_id = g.id AND c.checked_out IS NULL
      LEFT JOIN LATERAL (
        SELECT SUM(amount) AS today_revenue
        FROM payments
        WHERE gym_id = g.id AND paid_at >= CURRENT_DATE
      ) p ON TRUE
      GROUP BY g.id, g.name, g.city, g.capacity, g.status, g.opens_at, g.closes_at, p.today_revenue
      ORDER BY g.name
    `);
    res.json(rows);
  } catch (err) {
    console.error('/api/gyms error:', err.message);
    res.status(500).json({ error: 'Failed to fetch gyms' });
  }
});

// ============================================================
// GET /api/gyms/:id/live — single gym live snapshot < 5ms
// ============================================================
router.get('/gyms/:id/live', async (req, res) => {
  const { id } = req.params;
  try {
    const { rows: [gym] } = await pool.query(
      `SELECT id, name, city, capacity, status, opens_at, closes_at FROM gyms WHERE id = $1`,
      [id]
    );
    if (!gym) return res.status(404).json({ error: 'Gym not found' });

    const [occResult, revResult, eventsResult, anomaliesResult] = await Promise.all([
      pool.query(
        `SELECT COUNT(*) AS cnt FROM checkins WHERE gym_id = $1 AND checked_out IS NULL`,
        [id]
      ),
      pool.query(
        `SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE gym_id = $1 AND paid_at >= CURRENT_DATE`,
        [id]
      ),
      pool.query(`
        SELECT 'checkin' AS type, m.name AS member_name, c.checked_in AS ts
        FROM checkins c JOIN members m ON m.id = c.member_id
        WHERE c.gym_id = $1
        ORDER BY c.checked_in DESC LIMIT 20
      `, [id]),
      pool.query(
        `SELECT * FROM anomalies WHERE gym_id = $1 AND resolved = FALSE ORDER BY detected_at DESC`,
        [id]
      ),
    ]);

    const occupancy = parseInt(occResult.rows[0].cnt, 10);
    res.json({
      gym,
      current_occupancy: occupancy,
      occupancy_pct: Math.round((occupancy / gym.capacity) * 100),
      today_revenue: parseFloat(revResult.rows[0].total),
      recent_events: eventsResult.rows,
      active_anomalies: anomaliesResult.rows,
    });
  } catch (err) {
    console.error('/api/gyms/:id/live error:', err.message);
    res.status(500).json({ error: 'Failed to fetch live data' });
  }
});

// ============================================================
// GET /api/gyms/:id/analytics
// ============================================================
router.get('/gyms/:id/analytics', async (req, res) => {
  const { id } = req.params;
  const range = req.query.dateRange || '30d';
  const intervalMap = { '7d': '7 days', '30d': '30 days', '90d': '90 days' };
  const interval = intervalMap[range] || '30 days';

  try {
    const [heatmap, revenue, churn, ratio] = await Promise.all([
      // Q4: Peak hour heatmap from materialized view
      pool.query(
        `SELECT day_of_week, hour_of_day, checkin_count
         FROM gym_hourly_stats WHERE gym_id = $1
         ORDER BY day_of_week, hour_of_day`,
        [id]
      ),
      // Q2: Revenue by plan type
      pool.query(`
        SELECT plan_type, SUM(amount) AS total, COUNT(*) AS count
        FROM payments
        WHERE gym_id = $1 AND paid_at >= NOW() - INTERVAL '${interval}'
        GROUP BY plan_type
      `, [id]),
      // Q3: Churn risk members (partial index used)
      pool.query(`
        SELECT id, name, last_checkin_at,
          CASE
            WHEN last_checkin_at < NOW() - INTERVAL '60 days' THEN 'CRITICAL'
            ELSE 'HIGH'
          END AS risk_level
        FROM members
        WHERE gym_id = $1
          AND status = 'active'
          AND last_checkin_at < NOW() - INTERVAL '45 days'
        ORDER BY last_checkin_at ASC
        LIMIT 100
      `, [id]),
      // New vs renewal ratio
      pool.query(`
        SELECT
          member_type,
          COUNT(*) AS count
        FROM members
        WHERE gym_id = $1
          AND joined_at >= NOW() - INTERVAL '${interval}'
        GROUP BY member_type
      `, [id]),
    ]);

    res.json({
      heatmap: heatmap.rows,
      revenue_by_plan: revenue.rows,
      churn_risk: churn.rows,
      new_vs_renewal: ratio.rows,
    });
  } catch (err) {
    console.error('/api/gyms/:id/analytics error:', err.message);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// ============================================================
// GET /api/anomalies
// ============================================================
router.get('/anomalies', async (req, res) => {
  const { gym_id, severity } = req.query;
  try {
    let query = `
      SELECT a.*, g.name AS gym_name
      FROM anomalies a
      JOIN gyms g ON g.id = a.gym_id
      WHERE a.resolved = FALSE
    `;
    const params = [];

    if (gym_id) {
      params.push(gym_id);
      query += ` AND a.gym_id = $${params.length}`;
    }
    if (severity) {
      params.push(severity);
      query += ` AND a.severity = $${params.length}`;
    }

    query += ' ORDER BY a.detected_at DESC';

    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    console.error('/api/anomalies error:', err.message);
    res.status(500).json({ error: 'Failed to fetch anomalies' });
  }
});

// ============================================================
// PATCH /api/anomalies/:id/dismiss
// ============================================================
router.patch('/anomalies/:id/dismiss', async (req, res) => {
  const { id } = req.params;
  try {
    const { rows: [anomaly] } = await pool.query(
      'SELECT * FROM anomalies WHERE id = $1',
      [id]
    );
    if (!anomaly) return res.status(404).json({ error: 'Anomaly not found' });
    if (anomaly.severity === 'critical') {
      return res.status(403).json({ error: 'Critical anomalies cannot be dismissed' });
    }

    const { rows: [updated] } = await pool.query(
      `UPDATE anomalies SET dismissed = TRUE, resolved = TRUE, resolved_at = NOW()
       WHERE id = $1 RETURNING *`,
      [id]
    );
    res.json(updated);
  } catch (err) {
    console.error('/api/anomalies/:id/dismiss error:', err.message);
    res.status(500).json({ error: 'Failed to dismiss anomaly' });
  }
});

// ============================================================
// GET /api/analytics/cross-gym — Q5: Cross-gym revenue < 2ms
// ============================================================
router.get('/analytics/cross-gym', async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        g.id AS gym_id,
        g.name AS gym_name,
        g.city,
        COALESCE(SUM(p.amount), 0) AS total_revenue,
        RANK() OVER (ORDER BY COALESCE(SUM(p.amount), 0) DESC) AS rank
      FROM gyms g
      LEFT JOIN payments p ON p.gym_id = g.id
        AND p.paid_at >= NOW() - INTERVAL '30 days'
      GROUP BY g.id, g.name, g.city
      ORDER BY total_revenue DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error('/api/analytics/cross-gym error:', err.message);
    res.status(500).json({ error: 'Failed to fetch cross-gym analytics' });
  }
});

// ============================================================
// GET /api/analytics/summary — All-gym aggregate
// ============================================================
router.get('/analytics/summary', async (req, res) => {
  try {
    const { rows: [summary] } = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM checkins WHERE checked_out IS NULL) AS total_checked_in,
        (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE paid_at >= CURRENT_DATE) AS total_today_revenue,
        (SELECT COUNT(*) FROM anomalies WHERE resolved = FALSE) AS active_anomalies,
        (SELECT COUNT(*) FROM members WHERE status = 'active') AS total_active_members
    `);
    res.json(summary);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch summary' });
  }
});

// ============================================================
// Simulator routes
// ============================================================
router.post('/simulator/start', (req, res) => {
  const speed = parseInt(req.body?.speed, 10) || 1;
  if (![1, 5, 10].includes(speed)) {
    return res.status(400).json({ error: 'Speed must be 1, 5, or 10' });
  }
  const result = startSimulator(speed);
  res.json(result);
});

router.post('/simulator/stop', (req, res) => {
  const result = stopSimulator();
  res.json(result);
});

router.post('/simulator/reset', async (req, res) => {
  const result = await resetSimulator();
  res.json(result);
});

router.get('/simulator/status', (req, res) => {
  res.json(getStatus());
});

module.exports = router;
