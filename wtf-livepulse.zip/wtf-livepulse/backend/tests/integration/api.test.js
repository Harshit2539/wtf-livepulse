/**
 * Integration Tests - REST API Endpoints
 * Uses Supertest against the running Express app.
 * Requires DATABASE_URL env var pointing to a seeded test database.
 */

const request = require('supertest');

// Only import app - do NOT start the server (supertest handles it)
let app;

beforeAll(async () => {
  process.env.DATABASE_URL = process.env.DATABASE_URL || 'postgres://wtf:wtf_secret@localhost:5432/wtf_livepulse';
  process.env.PORT = '3099'; // Test port

  // Dynamically require after env is set
  const mod = require('../../src/app');
  app = mod.app;

  // Give DB a moment
  await new Promise(r => setTimeout(r, 500));
});

afterAll(async () => {
  const { server } = require('../../src/app');
  if (server && server.close) server.close();
  const pool = require('../../src/db/pool');
  await pool.end();
});

// ─────────────────────────────────────────────────────────────
// Health check
// ─────────────────────────────────────────────────────────────
describe('GET /health', () => {
  test('returns 200 with status ok', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});

// ─────────────────────────────────────────────────────────────
// GET /api/gyms
// ─────────────────────────────────────────────────────────────
describe('GET /api/gyms', () => {
  test('returns 200 with array of gyms', async () => {
    const res = await request(app).get('/api/gyms');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('returns exactly 10 gyms after seeding', async () => {
    const res = await request(app).get('/api/gyms');
    expect(res.body.length).toBe(10);
  });

  test('each gym has required fields', async () => {
    const res = await request(app).get('/api/gyms');
    const gym = res.body[0];
    expect(gym).toHaveProperty('id');
    expect(gym).toHaveProperty('name');
    expect(gym).toHaveProperty('city');
    expect(gym).toHaveProperty('capacity');
    expect(gym).toHaveProperty('current_occupancy');
    expect(gym).toHaveProperty('today_revenue');
    expect(gym).toHaveProperty('status');
  });

  test('Bandra West has expected capacity 300', async () => {
    const res = await request(app).get('/api/gyms');
    const bandra = res.body.find(g => g.name.includes('Bandra'));
    expect(bandra).toBeDefined();
    expect(parseInt(bandra.capacity)).toBe(300);
  });
});

// ─────────────────────────────────────────────────────────────
// GET /api/gyms/:id/live
// ─────────────────────────────────────────────────────────────
describe('GET /api/gyms/:id/live', () => {
  let gymId;

  beforeAll(async () => {
    const res = await request(app).get('/api/gyms');
    gymId = res.body[0]?.id;
  });

  test('returns 200 with all required live fields', async () => {
    const res = await request(app).get(`/api/gyms/${gymId}/live`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('gym');
    expect(res.body).toHaveProperty('current_occupancy');
    expect(res.body).toHaveProperty('occupancy_pct');
    expect(res.body).toHaveProperty('today_revenue');
    expect(res.body).toHaveProperty('recent_events');
    expect(res.body).toHaveProperty('active_anomalies');
  });

  test('returns 404 for unknown gym id', async () => {
    const res = await request(app).get('/api/gyms/00000000-0000-0000-0000-000000000000/live');
    expect(res.status).toBe(404);
  });

  test('returns 404 for invalid uuid format', async () => {
    const res = await request(app).get('/api/gyms/not-a-uuid/live');
    expect(res.status).toBeGreaterThanOrEqual(400);
  });
});

// ─────────────────────────────────────────────────────────────
// GET /api/anomalies
// ─────────────────────────────────────────────────────────────
describe('GET /api/anomalies', () => {
  test('returns 200 with array', async () => {
    const res = await request(app).get('/api/anomalies');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('accepts gym_id query param', async () => {
    const gymsRes = await request(app).get('/api/gyms');
    const gymId = gymsRes.body[0]?.id;
    const res = await request(app).get(`/api/anomalies?gym_id=${gymId}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('accepts severity query param', async () => {
    const res = await request(app).get('/api/anomalies?severity=critical');
    expect(res.status).toBe(200);
    res.body.forEach(a => expect(a.severity).toBe('critical'));
  });
});

// ─────────────────────────────────────────────────────────────
// PATCH /api/anomalies/:id/dismiss
// ─────────────────────────────────────────────────────────────
describe('PATCH /api/anomalies/:id/dismiss', () => {
  test('returns 403 when trying to dismiss a critical anomaly', async () => {
    // First ensure a critical anomaly exists (Bandra West capacity breach)
    const anomaliesRes = await request(app).get('/api/anomalies?severity=critical');
    if (anomaliesRes.body.length === 0) {
      // Create one via DB directly or skip
      console.warn('No critical anomaly found, skipping dismiss test');
      return;
    }
    const criticalId = anomaliesRes.body[0].id;
    const res = await request(app).patch(`/api/anomalies/${criticalId}/dismiss`);
    expect(res.status).toBe(403);
    expect(res.body.error).toMatch(/critical/i);
  });

  test('returns 404 for non-existent anomaly', async () => {
    const res = await request(app).patch('/api/anomalies/00000000-0000-0000-0000-000000000000/dismiss');
    expect(res.status).toBe(404);
  });
});

// ─────────────────────────────────────────────────────────────
// GET /api/analytics/cross-gym
// ─────────────────────────────────────────────────────────────
describe('GET /api/analytics/cross-gym', () => {
  test('returns 200 with 10 gym revenue entries', async () => {
    const res = await request(app).get('/api/analytics/cross-gym');
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(10);
  });

  test('each entry has gym_id, gym_name, total_revenue, rank', async () => {
    const res = await request(app).get('/api/analytics/cross-gym');
    const entry = res.body[0];
    expect(entry).toHaveProperty('gym_id');
    expect(entry).toHaveProperty('gym_name');
    expect(entry).toHaveProperty('total_revenue');
    expect(entry).toHaveProperty('rank');
  });

  test('results are sorted descending by revenue', async () => {
    const res = await request(app).get('/api/analytics/cross-gym');
    const revenues = res.body.map(r => parseFloat(r.total_revenue));
    for (let i = 1; i < revenues.length; i++) {
      expect(revenues[i]).toBeLessThanOrEqual(revenues[i - 1]);
    }
  });
});

// ─────────────────────────────────────────────────────────────
// POST /api/simulator/start & stop
// ─────────────────────────────────────────────────────────────
describe('POST /api/simulator/start', () => {
  test('returns status running with valid speed', async () => {
    const res = await request(app)
      .post('/api/simulator/start')
      .send({ speed: 1 });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('running');
  });

  test('returns 400 for invalid speed', async () => {
    const res = await request(app)
      .post('/api/simulator/start')
      .send({ speed: 99 });
    expect(res.status).toBe(400);
  });
});

describe('POST /api/simulator/stop', () => {
  test('returns status paused', async () => {
    const res = await request(app).post('/api/simulator/stop');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('paused');
  });
});

// ─────────────────────────────────────────────────────────────
// GET /api/gyms/:id/analytics
// ─────────────────────────────────────────────────────────────
describe('GET /api/gyms/:id/analytics', () => {
  let gymId;

  beforeAll(async () => {
    const res = await request(app).get('/api/gyms');
    gymId = res.body[0]?.id;
  });

  test('returns heatmap, revenue_by_plan, churn_risk, new_vs_renewal', async () => {
    const res = await request(app).get(`/api/gyms/${gymId}/analytics`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('heatmap');
    expect(res.body).toHaveProperty('revenue_by_plan');
    expect(res.body).toHaveProperty('churn_risk');
    expect(res.body).toHaveProperty('new_vs_renewal');
  });

  test('accepts dateRange query param', async () => {
    const res = await request(app).get(`/api/gyms/${gymId}/analytics?dateRange=7d`);
    expect(res.status).toBe(200);
  });
});
