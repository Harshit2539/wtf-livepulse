/**
 * Unit Tests - Anomaly Detection Logic
 * Tests anomaly business rules independently of the database.
 */

// ── Pure logic helpers extracted for unit testing ────────────────────────────

function isOperatingHours(hour) {
  return hour >= 6 && hour < 22;
}

function detectZeroCheckins({ lastCheckinMinutesAgo, isOperating, gymStatus }) {
  if (!isOperating) return null;
  if (gymStatus !== 'active') return null;
  if (lastCheckinMinutesAgo > 120) {
    return { type: 'zero_checkins', severity: 'warning' };
  }
  return null;
}

function detectCapacityBreach({ currentOccupancy, capacity }) {
  const pct = currentOccupancy / capacity;
  if (pct > 0.90) {
    return { type: 'capacity_breach', severity: 'critical', pct: Math.round(pct * 100) };
  }
  return null;
}

function shouldResolveCapacityBreach({ currentOccupancy, capacity }) {
  return (currentOccupancy / capacity) < 0.85;
}

function detectRevenueDrop({ todayRevenue, lastWeekRevenue }) {
  if (lastWeekRevenue <= 0) return null;
  const dropRatio = (lastWeekRevenue - todayRevenue) / lastWeekRevenue;
  if (dropRatio >= 0.30) {
    return { type: 'revenue_drop', severity: 'warning', dropPct: Math.round(dropRatio * 100) };
  }
  return null;
}

function shouldResolveRevenueDrop({ todayRevenue, lastWeekRevenue }) {
  if (lastWeekRevenue <= 0) return false;
  return todayRevenue >= lastWeekRevenue * 0.80;
}

// ── Hour distribution helper ──────────────────────────────────────────────────

const HOUR_WEIGHTS = [
  0.00, 0.00, 0.00, 0.00, 0.00, 0.30,
  0.60, 1.00, 1.00, 1.00, 0.40, 0.40,
  0.30, 0.30, 0.20, 0.20, 0.20, 0.90,
  0.90, 0.90, 0.90, 0.35, 0.15, 0.00,
];

function generateCheckinHour() {
  const totalWeight = HOUR_WEIGHTS.reduce((a, b) => a + b, 0);
  let r = Math.random() * totalWeight;
  for (let h = 0; h < 24; h++) {
    r -= HOUR_WEIGHTS[h];
    if (r <= 0) return h;
  }
  return 7; // fallback
}

// ═══════════════════════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════════════════════

describe('Zero Check-ins Anomaly Detection', () => {
  test('fires when active gym has no check-ins for > 2 hours during operating hours', () => {
    const result = detectZeroCheckins({
      lastCheckinMinutesAgo: 150,
      isOperating: true,
      gymStatus: 'active',
    });
    expect(result).not.toBeNull();
    expect(result.type).toBe('zero_checkins');
    expect(result.severity).toBe('warning');
  });

  test('does NOT fire when check-in was 90 minutes ago', () => {
    const result = detectZeroCheckins({
      lastCheckinMinutesAgo: 90,
      isOperating: true,
      gymStatus: 'active',
    });
    expect(result).toBeNull();
  });

  test('does NOT fire outside operating hours (midnight)', () => {
    const result = detectZeroCheckins({
      lastCheckinMinutesAgo: 300,
      isOperating: false,
      gymStatus: 'active',
    });
    expect(result).toBeNull();
  });

  test('does NOT fire for inactive gym', () => {
    const result = detectZeroCheckins({
      lastCheckinMinutesAgo: 200,
      isOperating: true,
      gymStatus: 'inactive',
    });
    expect(result).toBeNull();
  });

  test('isOperatingHours returns true for hour 6-21', () => {
    expect(isOperatingHours(6)).toBe(true);
    expect(isOperatingHours(21)).toBe(true);
    expect(isOperatingHours(5)).toBe(false);
    expect(isOperatingHours(22)).toBe(false);
  });
});

describe('Capacity Breach Anomaly Detection', () => {
  test('fires when occupancy exceeds 90% of capacity', () => {
    const result = detectCapacityBreach({ currentOccupancy: 275, capacity: 300 });
    expect(result).not.toBeNull();
    expect(result.type).toBe('capacity_breach');
    expect(result.severity).toBe('critical');
    expect(result.pct).toBeGreaterThan(90);
  });

  test('does NOT fire at exactly 90% capacity', () => {
    const result = detectCapacityBreach({ currentOccupancy: 270, capacity: 300 });
    expect(result).toBeNull();
  });

  test('does NOT fire at 85% capacity', () => {
    const result = detectCapacityBreach({ currentOccupancy: 255, capacity: 300 });
    expect(result).toBeNull();
  });

  test('severity is critical (not warning) for capacity breach', () => {
    const result = detectCapacityBreach({ currentOccupancy: 290, capacity: 300 });
    expect(result.severity).toBe('critical');
  });

  test('auto-resolves when occupancy drops below 85%', () => {
    expect(shouldResolveCapacityBreach({ currentOccupancy: 250, capacity: 300 })).toBe(true);
    expect(shouldResolveCapacityBreach({ currentOccupancy: 260, capacity: 300 })).toBe(false);
  });
});

describe('Revenue Drop Anomaly Detection', () => {
  test('fires when today revenue is 70% below last week same day', () => {
    const result = detectRevenueDrop({ todayRevenue: 1499, lastWeekRevenue: 18000 });
    expect(result).not.toBeNull();
    expect(result.type).toBe('revenue_drop');
    expect(result.severity).toBe('warning');
    expect(result.dropPct).toBeGreaterThanOrEqual(70);
  });

  test('fires when drop is exactly 30%', () => {
    const result = detectRevenueDrop({ todayRevenue: 7000, lastWeekRevenue: 10000 });
    expect(result).not.toBeNull();
  });

  test('does NOT fire when drop is less than 30%', () => {
    const result = detectRevenueDrop({ todayRevenue: 8000, lastWeekRevenue: 10000 });
    expect(result).toBeNull();
  });

  test('does NOT fire when last week revenue is zero', () => {
    const result = detectRevenueDrop({ todayRevenue: 0, lastWeekRevenue: 0 });
    expect(result).toBeNull();
  });

  test('auto-resolves when revenue recovers within 20% of last week', () => {
    expect(shouldResolveRevenueDrop({ todayRevenue: 9000, lastWeekRevenue: 10000 })).toBe(true);
    expect(shouldResolveRevenueDrop({ todayRevenue: 5000, lastWeekRevenue: 10000 })).toBe(false);
  });
});

describe('Simulator Time Distribution', () => {
  test('generates check-in hours weighted toward peak times (7-9am, 5-8pm)', () => {
    const counts = new Array(24).fill(0);
    const SAMPLES = 10000;

    for (let i = 0; i < SAMPLES; i++) {
      counts[generateCheckinHour()]++;
    }

    const morningPeak = counts.slice(7, 10).reduce((a, b) => a + b, 0);
    const eveningPeak = counts.slice(17, 21).reduce((a, b) => a + b, 0);
    const deadNight = counts.slice(0, 5).reduce((a, b) => a + b, 0);

    // Peak hours should be heavily represented
    expect(morningPeak).toBeGreaterThan(SAMPLES * 0.20);
    expect(eveningPeak).toBeGreaterThan(SAMPLES * 0.20);
    // Dead night hours should be zero
    expect(deadNight).toBe(0);
    // No check-ins at hour 23 (closed)
    expect(counts[23]).toBe(0);
  });
});
