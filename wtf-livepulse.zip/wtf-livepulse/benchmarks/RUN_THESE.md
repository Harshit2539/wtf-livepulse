# Benchmark Queries — Run These After Seeding

Connect to PostgreSQL and run each query with EXPLAIN ANALYZE.
Save screenshots of the output to this directory.

```sql
-- Q1: Live Occupancy (< 0.5ms target)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT COUNT(*) FROM checkins
WHERE gym_id = (SELECT id FROM gyms WHERE name ILIKE '%Bandra%')
AND checked_out IS NULL;

-- Q2: Today's Revenue (< 0.8ms target)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT SUM(amount) FROM payments
WHERE gym_id = (SELECT id FROM gyms WHERE name ILIKE '%Bandra%')
AND paid_at >= CURRENT_DATE;

-- Q3: Churn Risk Members (< 1ms target)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT id, name, last_checkin_at FROM members
WHERE status = 'active'
AND last_checkin_at < NOW() - INTERVAL '45 days';

-- Q4: Peak Hour Heatmap via Materialized View (< 0.3ms target)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT * FROM gym_hourly_stats
WHERE gym_id = (SELECT id FROM gyms WHERE name ILIKE '%Bandra%');

-- Q5: Cross-Gym Revenue Comparison (< 2ms target)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT gym_id, SUM(amount) AS total
FROM payments
WHERE paid_at >= NOW() - INTERVAL '30 days'
GROUP BY gym_id
ORDER BY total DESC;

-- Q6: Active Anomalies All Gyms (< 0.3ms target)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT * FROM anomalies
WHERE resolved = FALSE
ORDER BY detected_at DESC;
```

Run via Docker:
```bash
docker exec -it <db_container> psql -U wtf -d wtf_livepulse
```
